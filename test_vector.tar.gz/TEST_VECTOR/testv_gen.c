#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NO_16BIT_VEC 16
#define NO_8BIT_VEC 32


unsigned short vec16_1[NO_16BIT_VEC], vec16_2[NO_16BIT_VEC];
unsigned char vec8_1[NO_8BIT_VEC], vec8_2[NO_8BIT_VEC];
unsigned short vmac_dest[NO_16BIT_VEC];

enum OP {CONF, ADD, SUB, RSUB, ADC, SBC, MIN, MINU, MAX, MAXU, AND, OR, XOR, SLL, SRL, SRA,
		MUL, 
		MULH,
		MULHU,
		MULHSU,
		MADD, 
		NMSUB,
		MACC,
		NMSAC,
		LOAD_STORE, 
		SCALR_MOV};
unsigned int V0_ADC_SBC;
/* 
  RX: X register value used in VX mode
  RX_NO: X reg. number used in VX mode
  IMM: immediate value used in VI mode
*/
unsigned int RX, RX_NO = 17, IMM;


void 
gen_inputs()
{
   int i;
   time_t t;
   /* Intializes random number generator */
   srand((unsigned) time(&t));

   for (i = 0; i < NO_16BIT_VEC; i++) {
	 vec16_1[i] = rand() % 0xFFFF;
	 vec16_2[i] = rand() % 0xFFFF;
	 vmac_dest[i] = rand() % 0xFFFF;
   }

   for (i = 0; i < NO_8BIT_VEC; i++) {
	 vec8_1[i] = rand() % 0xFF;
	 vec8_2[i] = rand() % 0xFF;
   }

   V0_ADC_SBC = rand() % 0xFFFFFFFF;
   RX = rand() % 0xFFFFFFFF;
   IMM = rand() % 0x10;
}

void
gen_input_data_section(FILE *fp)
{
  int i;

  /* 16-bit input 1 */
  fprintf(fp, "\t.section .rodata\n");
  fprintf(fp, "\t.align 2\n");
  fprintf(fp, ".VECTOR16_1:\n");
  for (i = 0; i < NO_16BIT_VEC; i++) 
	fprintf(fp, "\t.short\t0x%04x\n", vec16_1[i]);

  /* 16-bit input 2 */
  fprintf(fp, "\n");
  fprintf(fp, ".VECTOR16_2:\n");
  for (i = 0; i < NO_16BIT_VEC; i++) 
	fprintf(fp, "\t.short\t0x%04x\n", vec16_2[i]);

  /* 16-bit VMAC_DEST */
  fprintf(fp, "\n");
  fprintf(fp, ".VMAC_DEST:\n");
  for (i = 0; i < NO_16BIT_VEC; i++) 
	fprintf(fp, "\t.short\t0x%04x\n", vmac_dest[i]);

  /* 8-bit input 1 */
  fprintf(fp, "\n");
  fprintf(fp, "\t.align 1\n");
  fprintf(fp, ".VECTOR8_1:\n");
  for (i = 0; i < NO_8BIT_VEC; i++) 
	fprintf(fp, "\t.byte\t0x%02x\n", vec8_1[i]);

  /* 8-bit input 2 */
  fprintf(fp, "\n");
  fprintf(fp, ".VECTOR8_2:\n");
  for (i = 0; i < NO_8BIT_VEC; i++) 
	fprintf(fp, "\t.byte\t0x%02x\n", vec8_2[i]);
}


int sign_ext16(int a)
{
  int re;

  a = a & 0xFFFF;
  if (a & 0x8000) return (0xFFFF0000 | a);
  else return a;
}

int sign_ext8(int a)
{
  int re;

  a = a & 0xFF;
  if (a & 0x80) return (0xFFFFFF00 | a);
  else return a;
}




int 
min8(int a, int b) 
{
  a = a & 0xFF;
  b = b & 0xFF;

  if ((a & 0x80) && (b & 0x80)) {
	return a > b ? b : a;
  }
  else if ((a & 0x80) && (b & 0x80) == 0) {
	return a;
  }
  else if ((a & 0x80) == 0 && (b & 0x80)) {
	return b;
  }
  else {
	return a > b ? b : a;
  }
}

int 
min16(int a, int b) 
{
  a = a & 0xFFFF;
  b = b & 0xFFFF;

  if ((a & 0x8000) && (b & 0x8000)) {
	return a > b ? b : a;
  }
  else if ((a & 0x8000) && (b & 0x8000) == 0) {
	return a;
  }
  else if ((a & 0x8000) == 0 && (b & 0x8000)) {
	return b;
  }
  else {
	return a > b ? b : a;
  }
}

int 
max8(int a, int b) 
{
  a = a & 0xFF;
  b = b & 0xFF;

  if ((a & 0x80) && (b & 0x80)) {
	return a > b ? a : b;
  }
  else if ((a & 0x80) && (b & 0x80) == 0) {
	return b;
  }
  else if ((a & 0x80) == 0 && (b & 0x80)) {
	return a;
  }
  else {
	return a > b ? a : b;
  }
}

int 
max16(int a, int b) 
{
  a = a & 0xFFFF;
  b = b & 0xFFFF;

  if ((a & 0x8000) && (b & 0x8000)) {
	return a > b ? a : b;
  }
  else if ((a & 0x8000) && (b & 0x8000) == 0) {
	return b;
  }
  else if ((a & 0x8000) == 0 && (b & 0x8000)) {
	return a;
  }
  else {
	return a > b ? a : b;
  }
}

int 
sra16(int v, int n)
{
  int s;
  int i;
  v = v & 0xFFFF;
  n = n & 0xF;
  s = v & 0x8000;

  if (s) {
	for (i = 0; i < n; i++) {
	  v = v >> 1;
	  v = v | 0x8000;
	}
  }
  else {
	v = (v >> n);
  }
  return v & 0xFFFF;
}

int 
sra8(int v, int n)
{
  int i;
  int s;
  v = v & 0xFFFF;
  n = n & 0x7;
  s = v & 0x80;

  if (s) {
	for (i = 0; i < n; i++) {
	  v = v >> 1;
	  v = v | 0x80;
	}
  }
  else {
	v = (v >> n);
  }
  return v & 0xFFFF;
}


void
gen_expected_data_section(FILE *fp, enum OP op)
{
  int i;

  switch (op) {
	case ADD: {
	  fprintf(fp, "\t.align 2\n");
	  fprintf(fp, "\n.VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] & 0xFFFF + vec16_2[i] & 0xFFFF) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] & 0xFFFF + (RX & 0xFFFF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] & 0xFFFF + (IMM & 0xFFFF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, "\t.align 1\n");
	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + (RX & 0xFF)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + (IMM & 0xFF)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  break;
	}
	case SUB: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] - vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] - vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] - (RX & 0xFFFF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] - (RX & 0xFF)) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case RSUB: {
	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((RX & 0xFFFF) - vec16_1[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((RX & 0xFF) - vec8_1[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((IMM & 0xFFFF) - vec16_1[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((IMM & 0xFF) - vec8_1[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case ADC: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] + vec16_2[i] + ((V0_ADC_SBC >> i) & 0x1)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + vec8_2[i] + ((V0_ADC_SBC >> i)&0x1)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] + (RX & 0xFFFF) + ((V0_ADC_SBC >> i)&0x1)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + (RX & 0xFF) + ((V0_ADC_SBC >> i)&0x1)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] + (IMM & 0xFFFF) + ((V0_ADC_SBC >> i)&0x1)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] + (IMM & 0xFF) + ((V0_ADC_SBC >> i)&0x1)) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case SBC: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] - vec16_2[i] - ((V0_ADC_SBC >> i)&0x1)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] - vec8_2[i] - ((V0_ADC_SBC >> i)&0x1)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] - (RX & 0xFFFF) - ((V0_ADC_SBC >> i)&0x1)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] - (RX & 0xFF) - ((V0_ADC_SBC >> i)&0x1)) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MIN: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", min16(vec16_1[i], vec16_2[i]));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", min8(vec8_1[i], vec8_2[i]));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", min16(vec16_1[i], RX));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", min8(vec8_1[i], RX));
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case MINU: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((vec16_1[i]&0xFFFF) < (vec16_2[i]&0xFFFF) ? vec16_1[i] : vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((vec8_1[i]&0xFF) < (vec8_2[i]&0xFF) ? vec8_1[i] : vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((vec16_1[i]&0xFFFF) < (RX&0xFFFF) ? vec16_1[i] : RX) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((vec8_1[i]&0xFF) < (RX&0xFF) ? vec8_1[i] : RX) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case MAX: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", max16(vec16_1[i], vec16_2[i]));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", max8(vec8_1[i], vec8_2[i]));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", max16(vec16_1[i], RX));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", max8(vec8_1[i], RX));
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MAXU: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((vec16_1[i] & 0xFFFF) > (vec16_2[i] & 0xFFFF) ? vec16_1[i] : vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((vec8_1[i] & 0xFF) > (vec8_2[i] & 0xFF) ? vec8_1[i] : vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((vec16_1[i] & 0xFFFF) > (RX & 0xFFFF) ? vec16_1[i] : RX) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((vec8_1[i] & 0xFF) > (RX & 0xFF) ? vec8_1[i] : RX) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case AND: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] & vec16_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] & vec8_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] & (RX & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] & (RX & 0xFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] & (IMM & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] & (IMM & 0xFF));
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case OR: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] | vec16_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] | vec8_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] | (RX & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] | (RX & 0xFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] | (IMM & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] | (IMM & 0xFF));
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case XOR: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] ^ vec16_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] ^ vec8_2[i]);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] ^ (RX & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] ^ (RX & 0xFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", vec16_1[i] ^ (IMM & 0xFFFF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", vec8_1[i] ^ (IMM & 0xFF));
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case SLL: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] << (vec16_2[i] & 0xF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] << (vec8_2[i] & 0x7)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] << (RX & 0xF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] << (RX & 0x7)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (vec16_1[i] << (IMM & 0xF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (vec8_1[i] << (IMM & 0x7)) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case SRL: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (((unsigned) vec16_1[i] & 0xFFFF) >> (vec16_2[i] & 0xF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (((unsigned) vec8_1[i] & 0xFF) >> (vec8_2[i] & 0x7)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (((unsigned) vec16_1[i] & 0xFFFF) >> (RX & 0xF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (((unsigned) vec8_1[i] & 0xFF) >> (RX & 0x7)) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((unsigned) vec16_1[i] & 0xFFFF) >> (IMM & 0xF));
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((unsigned) vec8_1[i] & 0xFF) >> (IMM & 0x7));
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case SRA: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", sra16(vec16_1[i], vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", sra8(vec8_1[i], vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", sra16(vec16_1[i], RX) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", sra8(vec8_1[i], RX) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", sra16(vec16_1[i], IMM) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VI_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", sra8(vec8_1[i], IMM) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MUL: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)vec16_1[i] *  (signed)vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((signed)vec8_1[i] * (signed)vec8_2[i]) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)vec16_1[i] * (RX & 0xFFFF)) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((signed)vec8_1[i] * (RX & 0xFF)) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MULH: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((sign_ext16(vec16_1[i]) * sign_ext16(vec16_2[i])) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((sign_ext8(vec8_1[i]) * sign_ext8(vec8_2[i])) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((sign_ext16(vec16_1[i]) * sign_ext16(RX)) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((sign_ext8(vec8_1[i]) * sign_ext8(RX)) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MULHU: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((((vec16_1[i] & 0xFFFF) * (vec16_2[i] & 0xFFFF)) & 0xFFFF0000) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((((vec8_1[i] & 0xFF) * (vec8_2[i] & 0xFF)) & 0xFF00) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((((vec16_1[i] & 0xFFFF) * (RX & 0xFFFF)) & 0xFFFF0000) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", ((((vec8_1[i] & 0xFF) * (RX & 0xFF)) & 0xFF00) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
	case MULHSU: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (((sign_ext16(vec16_1[i]) * (vec16_2[i] & 0xFFFF)) & 0xFFFF0000) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VV_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (((sign_ext8(vec8_1[i]) * (vec8_2[i] & 0xFF)) & 0xFF00) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (((sign_ext16(vec16_1[i]) * (RX & 0xFFFF)) & 0xFFFF0000) >> 16) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED8:\n");
	  for (i = 0; i < NO_8BIT_VEC; i++) {
		fprintf(fp, "\t.byte 0x%02x\n", (((sign_ext8(vec8_1[i]) * (RX & 0xFF)) & 0xFF00) >> 8) & 0xFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case MADD: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)vec16_1[i] * (signed)vmac_dest[i] + (signed)vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)RX * (signed)vmac_dest[i] + (signed)vec16_1[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case NMSUB: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (-((signed)vec16_1[i] * (signed)vmac_dest[i]) + (signed)vec16_2[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (-((signed)RX * (signed)vmac_dest[i]) + (signed)vec16_1[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case MACC: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)vec16_1[i] * (signed)vec16_2[i] + (signed)vmac_dest[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", ((signed)RX * (signed)vec16_1[i] + (signed)vmac_dest[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}

	case NMSAC: {
	  fprintf(fp, ".VV_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (-((signed)vec16_1[i] * (signed)vec16_2[i]) + (signed)vmac_dest[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");

	  fprintf(fp, ".VX_EXPECTED16:\n");
	  for (i = 0; i < NO_16BIT_VEC; i++) {
		fprintf(fp, "\t.short 0x%04x\n", (-((signed)RX * (signed)vec16_1[i]) + (signed)vmac_dest[i]) & 0xFFFF);
	  }
	  fprintf(fp, "\n");
	  break;
	}
  }
}

void gen_header_code(FILE *fp)
{
  fprintf(fp, "\t.text\n");
  fprintf(fp, "\t.globl main\n");
  fprintf(fp, "\t.attribute 5, \"rv32imafc_v0p10\"\n");
  fprintf(fp, "\t.type main,@function\n");
  fprintf(fp, "main:\n");
  fprintf(fp, "\tli x1, 8\n");
  fprintf(fp, "\tli x2, 16\n");

}

#define VLOAD(n, d, t1, t2, L) do {				\
  fprintf(fp, "\tlui %s, %%hi(%s)\n", t1, L);			\
  fprintf(fp, "\taddi %s, %s,  %%lo(%s)\n", t2, t1, L);		\
  fprintf(fp, "\tvle%s.v %s, (%s)\n", n, d, t2);			\
} while (0)

void 
gen_sub_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, SUB);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvsub.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsub.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvsub.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsub.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VSUB_END:\n");

  fclose(fp);
}


void 
gen_add_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, ADD);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvadd.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvadd.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvadd.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvadd.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvadd.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvadd.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VADD_END:\n");

  fclose(fp);
}


void 
gen_rsub_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, RSUB);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvrsub.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");


  fprintf(fp, "\tvrsub.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvrsub.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvrsub.vi v3, v1, 0x%x\n", IMM & 0xFF);
  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VRSUB_END:\n");

  fclose(fp);
}


void 
gen_adc_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, ADC);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  fprintf(fp, "\tlui x11, %%hi(0x%04x)\n", V0_ADC_SBC & 0xFFFF);
  fprintf(fp, "\taddi x12, x11,  %%lo(0x%04x)\n", V0_ADC_SBC & 0xFFFF);
  fprintf(fp, "\tvmv.s.x v0, x12\n");			

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvadc.vvm v3, v2, v4, v0\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvadc.vxm v3, v2, x%d, v0\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvadc.vim v3, v2, 0x%x, v0\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvadc.vvm v4, v1, v3, v0\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvadc.vxm v3, v1, x%d, v0\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvadc.vim v3, v1, 0x%x, v0\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VADC_END:\n");

  fclose(fp);
}

void 
gen_sbc_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, SBC);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  fprintf(fp, "\tlui x11, %%hi(0x%04x)\n", V0_ADC_SBC & 0xFFFF);
  fprintf(fp, "\taddi x12, x11,  %%lo(0x%04x)\n", V0_ADC_SBC & 0xFFFF);
  fprintf(fp, "\tvmv.s.x v0, x12\n");			

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvsbc.vvm v3, v2, v4, v0\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsbc.vxm v3, v2, x%d, v0\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvsbc.vvm v4, v1, v3, v0\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsbc.vxm v3, v1, x%d, v0\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VSBC_END:\n");

  fclose(fp);
}



void 
gen_min_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MIN);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmin.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmin.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmin.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmin.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMIN_END:\n");

  fclose(fp);
}

void 
gen_minu_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MINU);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvminu.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvminu.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvminu.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvminu.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMINU_END:\n");

  fclose(fp);
}


void 
gen_max_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MAX);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmax.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmax.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmax.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmax.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMAX_END:\n");

  fclose(fp);
}



void 
gen_maxu_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MAXU);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmaxu.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmaxu.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmaxu.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmaxu.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMAXU_END:\n");

  fclose(fp);
}


void 
gen_and_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, AND);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvand.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvand.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvand.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvand.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvand.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvand.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VAND_END:\n");

  fclose(fp);
}


void 
gen_or_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, OR);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvor.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvor.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvor.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvor.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvor.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvor.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VOR_END:\n");

  fclose(fp);
}

void 
gen_xor_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, XOR);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvxor.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvxor.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvxor.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvxor.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvxor.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvxor.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VXOR_END:\n");

  fclose(fp);
}

void 
gen_sll_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, SLL);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvsll.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsll.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvsll.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvsll.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsll.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvsll.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VSLL_END:\n");

  fclose(fp);
}

void 
gen_srl_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, SRL);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvsrl.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsrl.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvsrl.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvsrl.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsrl.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvsrl.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VSRL_END:\n");

  fclose(fp);
}

void 
gen_sra_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, SRA);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvsra.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v26, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsra.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v27, v3, v4\n");


  fprintf(fp, "\tvsra.vi v3, v2, 0x%x\n", IMM & 0xFF);
  VLOAD("16", "v4", "x7", "x8", ".VI_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvsra.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v29, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvsra.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v3, v4\n");

  fprintf(fp, "\tvsra.vi v3, v1, 0x%x\n", IMM & 0xFF);

  VLOAD("8", "v4", "x7", "x8", ".VI_EXPECTED8");

  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VSRA_END:\n");

  fclose(fp);
}

void 
gen_mul_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MUL);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmul.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmul.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmul.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmul.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMUL_END:\n");

  fclose(fp);
}

void 
gen_mulh_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MULH);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmulh.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulh.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmulh.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulh.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMULH_END:\n");

  fclose(fp);
}

void 
gen_mulhu_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MULHU);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmulhu.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulhu.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmulhu.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulhu.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMULHU_END:\n");

  fclose(fp);
}


void 
gen_mulhsu_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MULHSU);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  fprintf(fp, "\tvmulhsu.vv v3, v2, v4\n");

  VLOAD("16", "v6", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v28, v3, v6\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulhsu.vx v3, v2, x%d\n", RX_NO);
  VLOAD("16", "v4", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v29, v3, v4\n");

  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmulhsu.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmulhsu.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMULHSU_END:\n");

  fclose(fp);
}

void 
gen_madd_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MADD);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvmadd.vv v6, v2, v4\n");

  VLOAD("16", "v8", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v30, v6, v8\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvmadd.vx v6, x%d, v2\n", RX_NO);
  VLOAD("16", "v8", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v31, v6, v8\n");

  /*
  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmadd.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmadd.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");
  */

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMADD:\n");

  fclose(fp);
}

void 
gen_nmsub_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, NMSUB);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvnmsub.vv v6, v2, v4\n");

  VLOAD("16", "v8", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v30, v6, v8\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvnmsub.vx v6, x%d, v2\n", RX_NO);
  VLOAD("16", "v8", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v31, v6, v8\n");

  /*
  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvnmsub.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvnmsub.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");
  */

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VNMSUB:\n");

  fclose(fp);
}

void 
gen_macc_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, MACC);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvmacc.vv v6, v2, v4\n");

  VLOAD("16", "v8", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v30, v6, v8\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvmacc.vx v6, x%d, v2\n", RX_NO);
  VLOAD("16", "v8", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v31, v6, v8\n");

  /*
  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvmacc.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvmacc.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");
  */

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VMACC:\n");

  fclose(fp);
}

void 
gen_nmsac_vec(const char *fname)
{
  FILE *fp;
  fp = fopen(fname,"w+");
  
  gen_input_data_section(fp);
  gen_expected_data_section(fp, NMSAC);

  gen_header_code(fp);

  fprintf(fp, "\tvsetvli x9, x1, e16, m1\n");

  VLOAD("16", "v2", "x7", "x8", ".VECTOR16_1");
  VLOAD("16", "v4", "x7", "x8", ".VECTOR16_2");
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvnmsac.vv v6, v2, v4\n");

  VLOAD("16", "v8", "x7", "x8", ".VV_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v30, v6, v8\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  VLOAD("16", "v6", "x7", "x8", ".VMAC_DEST");
  fprintf(fp, "\tvnmsac.vx v6, x%d, v2\n", RX_NO);
  VLOAD("16", "v8", "x7", "x8", ".VX_EXPECTED16");
  fprintf(fp, "\tvmsne.vv v31, v6, v8\n");

  /*
  fprintf(fp, "\tvsetvli x9, x2, e8, m1\n");

  VLOAD("8", "v1", "x7", "x8", ".VECTOR8_1");
  VLOAD("8", "v3", "x7", "x8", ".VECTOR8_2");
  fprintf(fp, "\tvnmsac.vv v4, v1, v3\n");

  VLOAD("8", "v5", "x7", "x8", ".VV_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v30, v4, v5\n");

  fprintf(fp, "\tli x%d, 0x%x\n", RX_NO, RX & 0xFFFF);
  fprintf(fp, "\tvnmsac.vx v3, v1, x%d\n", RX_NO);

  VLOAD("8", "v4", "x7", "x8", ".VX_EXPECTED8");
  fprintf(fp, "\tvmsne.vv v31, v3, v4\n");
  */

  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");
  fprintf(fp, "\tnop\n");

  fprintf(fp, ".VNMSAC:\n");

  fclose(fp);
}



int 
main () {
   gen_inputs();

   /*
   gen_add_vec("vadd.s");
   gen_sub_vec("vsub.s");
   gen_rsub_vec("vrsub.s");
   gen_adc_vec("vadc.s");
   gen_sbc_vec("vsbc.s");
   gen_min_vec("vmin.s");
   gen_minu_vec("vminu.s");
   gen_max_vec("vmax.s");
   gen_maxu_vec("vmaxu.s");
   gen_and_vec("vand.s");
   gen_or_vec("vor.s");
   gen_xor_vec("vxor.s");
   gen_sll_vec("vsll.s");
   gen_srl_vec("vsrl.s");
   gen_sra_vec("vsra.s");
   gen_mul_vec("vmul.s");
   gen_mulh_vec("vmulh.s");
   gen_mulhu_vec("vmulhu.s");
   gen_mulhsu_vec("vmulhsu.s");
   gen_madd_vec("vmadd.s");
   gen_nmsub_vec("vnmsub.s");
   gen_macc_vec("vmacc.s");
   */
   gen_nmsac_vec("vnmsac.s");
   

   return 0;
}
